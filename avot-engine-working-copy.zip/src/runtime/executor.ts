// Graph executor stub
