// LLM adapter stub
