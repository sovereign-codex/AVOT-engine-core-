// AVOT Engine entrypoint
