// DSL compiler stub
